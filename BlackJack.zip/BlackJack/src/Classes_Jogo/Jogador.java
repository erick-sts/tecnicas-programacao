package Classes_Jogo;

import java.util.ArrayList;
import java.util.List;

public class Jogador {

    String nome;
    List<Cartas> mao = new ArrayList<>();
    int saldo;

    public Jogador(String nome) {
        this.nome = nome;
        this.saldo = 100;
    }

    public void receberCarta() {
        Cartas carta = Baralho.getInstance().pegarCarta();
        if (carta != null) {
            mao.add(carta);
            System.out.println(nome + " recebeu uma carta: " + carta.getNome());
        }
    }

    public int calcularTotalMao() {
        int total = 0;
        for (Cartas carta : mao) {
            total += carta.valor;
        }
        return total;
    }

    public boolean estourou() {
        return calcularTotalMao() > 21;
    }

    public void jogar() throws InterruptedException {
        // Jogador começa com duas cartas
        receberCarta();
        Thread.sleep(1000); // Adiciona atraso de 1 segundo após cada carta recebida
        receberCarta();
        Thread.sleep(1000); // Adiciona atraso de 1 segundo após cada carta recebida

        // Continuar jogando conforme a lógica existente
        while (true) {
            
            int totalMao = calcularTotalMao();
            System.out.println(nome + " - Total da mao: " + totalMao);

            if (totalMao >= 17 || estourou()) {
                break;
            }
            System.out.println("");
            receberCarta();
            Thread.sleep(1000); // Adiciona atraso de 1 segundo após cada carta recebida
        }
    }

    public void resetMao() {
        mao.clear();
    }

    public void apostar() {
        saldo -= 10;
    }

    public void ganharAposta() {
        saldo += 40;
    }

    public int getSaldo() {
        return saldo;
    }

}
