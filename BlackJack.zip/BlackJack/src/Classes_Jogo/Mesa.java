package Classes_Jogo;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Mesa {

    static Jogador p1, p2, p3, p4;

    public static void main(String[] args) throws InterruptedException {
        p1 = new Jogador("Erick");
        p2 = new Jogador("Matheus");
        p3 = new Jogador("Leon");
        p4 = new Jogador("Joao");

        int numeroRodadas = 7;

        for (int i = 1; i <= numeroRodadas; i++) {
            System.out.println("Rodada" + i);
            System.out.println("");
            iniciarRodada();
            System.out.println("==================================================================");
            System.out.println("Fim da rodada " + i + "!");
            determinarVencedorDaRodada();
            System.out.println("==================================================================");
            Baralho.getInstance().resetBaralho();
        }

        determinarVencedorFinal();

//        iniciarJogo();
    }

    public static void iniciarRodada() throws InterruptedException {

        //jogadores apostam
        p1.apostar();
        p2.apostar();
        p3.apostar();
        p4.apostar();

        // Criar threads para cada jogador
        Thread threadP1 = new Thread(() -> {
            try {
                p1.jogar();
            } catch (InterruptedException ex) {
                Logger.getLogger(Mesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        Thread threadP2 = new Thread(() -> {
            try {
                p2.jogar();
            } catch (InterruptedException ex) {
                Logger.getLogger(Mesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        Thread threadP3 = new Thread(() -> {
            try {
                p3.jogar();
            } catch (InterruptedException ex) {
                Logger.getLogger(Mesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        Thread threadP4 = new Thread(() -> {
            try {
                p4.jogar();
            } catch (InterruptedException ex) {
                Logger.getLogger(Mesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        // Iniciar as threads dos jogadores
        threadP1.start();
        threadP2.start();
        threadP3.start();
        threadP4.start();

        // Aguardar o término das threads dos jogadores
        threadP1.join();
        threadP2.join();
        threadP3.join();
        threadP4.join();

    }

    public static void determinarVencedorDaRodada() {
        List<Jogador> jogadores = Arrays.asList(p1, p2, p3, p4);
        Jogador vencedor = null;
        int maiorPontuacao = -1;

        for (Jogador jogador : jogadores) {
            int totalJogador = jogador.calcularTotalMao();
            if (totalJogador <= 21 && totalJogador > maiorPontuacao) {
                maiorPontuacao = totalJogador;
                vencedor = jogador;
            }
        }

        if (vencedor != null) {
            System.out.println(vencedor.nome + " venceu a rodada com " + maiorPontuacao + " pontos.");
            vencedor.ganharAposta();
        } else {
            System.out.println("Nenhum jogador venceu a rodada!");
        }

        for (Jogador jogador : jogadores) {
            jogador.resetMao();
        }
    }

    public static void determinarVencedorFinal() {
        List<Jogador> jogadores = Arrays.asList(p1, p2, p3, p4);
        Jogador vencedor = null;
        int maiorSaldo = -1;

        for (Jogador jogador : jogadores) {
            if (jogador.getSaldo() > maiorSaldo) {
                maiorSaldo = jogador.getSaldo();
                vencedor = jogador;
            }
            System.out.println(jogador.nome + " - Saldo final: " + jogador.getSaldo());
        }
        if (vencedor != null) {
            System.out.println(vencedor.nome + " é o vencedor final com " + maiorSaldo + " de saldo!");
        } else {
            System.out.println("Nenhum jogador venceu!");
        }
    }
}
