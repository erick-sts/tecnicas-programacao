package Classes_Jogo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Baralho {

    private List<Cartas> baralho;
    private static Baralho instance;

    private Baralho() {
        baralho = new ArrayList<>();
        inicializarBaralho();
    }

    public static Baralho getInstance() {
        if (instance == null) {
            instance = new Baralho();
        }
        return instance;
    }

    private void inicializarBaralho() {
        for (Naipes naipe : Naipes.values()) {
            for (NumerosCartas numero : NumerosCartas.values()) {
                baralho.add(new Cartas(naipe, numero, numero.getValor()));
            }
        }
        Collections.shuffle(baralho); // Embaralha o baralho
    }

    public int getQuantidadeCartas() {
        return baralho.size();
    }

    public synchronized Cartas pegarCarta() {
        if (baralho.size() > 0) {
            return baralho.remove(0);
        } else {
            return null;
        }
    }

    public void resetBaralho() {
        baralho.clear();
        inicializarBaralho();
    }
}
