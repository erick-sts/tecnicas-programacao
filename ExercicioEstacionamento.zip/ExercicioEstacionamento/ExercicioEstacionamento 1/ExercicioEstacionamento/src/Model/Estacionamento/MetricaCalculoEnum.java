
package Model.Estacionamento;

public enum MetricaCalculoEnum {
    UM_QUARTO_HORA ,
    HORA, 
    DIARIA, 
    AUTOMATICO;
}
