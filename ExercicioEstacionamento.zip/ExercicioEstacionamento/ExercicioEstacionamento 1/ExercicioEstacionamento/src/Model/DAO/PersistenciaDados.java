
package Model.DAO;

import Model.Estacionamento.ContaVeiculo;
import Model.Estacionamento.Veiculo;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PersistenciaDados {
    
    private Connection connection;
    
    
    String caminhoPadrao= "C:\\Backup_Estacionamento";
    int countBackup=0;
    
    
    public PersistenciaDados() {
           try {
               
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            String DATABASE_URL = "jdbc:derby://localhost:1527/bdteste";
            String usuario = "APP";
            String senha = "123";
            this.connection = DriverManager.getConnection(DATABASE_URL, usuario, senha);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(VeiculoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    public boolean inserirVeiculo(Veiculo veiculo) {
        if(!ehVeiculoCadastrado(veiculo.getPlaca())){
    try {
  
       
        String sql = "INSERT INTO VEICULOS (PLACA, TIPO_VEICULO, NOME_VEICULO) VALUES (?, ?, ?)";
        PreparedStatement stmt = connection.prepareStatement(sql);
        stmt.setString(1, veiculo.getPlaca());
        stmt.setString(2, veiculo.getNome());
        stmt.setString(3, veiculo.getTipo().toString());
        
        int rowsAffected = stmt.executeUpdate();
        
        // Verifica se pelo menos uma linha foi afetada (ou seja, se a inserção foi bem-sucedida)
        if (rowsAffected > 0) {
            return true;
        }
    } catch (SQLException ex) {
        Logger.getLogger(PersistenciaDados.class.getName()).log(Level.SEVERE, null, ex);
        return false;
    }
        }
       
    return false;
}

 
public boolean ehVeiculoCadastrado(String placa){
        String sql = "Select PLACA from VEICULOS";
        try{
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet resultado = stmt.executeQuery();
             while(resultado.next()){
                 if(resultado.getString("PLACA").equals(placa)){
                     return true;
                 }
             }
        }catch (SQLException ex){
            Logger.getLogger(PersistenciaDados.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
}
    
    
   public boolean criarNovoRegistro(ContaVeiculo elemento) {
    try {
        String sql = "INSERT INTO CONTA_VEICULO (PLACA, INICIO, FIM, STATUS) VALUES (?, ?, ?, ?)";
        
        // Preparar a instrução SQL
        PreparedStatement stmt = connection.prepareStatement(sql);
        stmt.setString(1, elemento.getVeiculo().getPlaca());
        stmt.setLong(2, elemento.getInicio());
        stmt.setLong(3, elemento.getFim());
        stmt.setString(4, elemento.getStatus().toString());
        
        // Executar a inserção
        int rowsAffected = stmt.executeUpdate();
        
        // Verificar se a inserção foi bem-sucedida
        if (rowsAffected > 0) {
            return true; // Retorna true se pelo menos uma linha foi afetada (inserida)
        }
    } catch (SQLException ex) {
        Logger.getLogger(PersistenciaDados.class.getName()).log(Level.SEVERE, null, ex);
    }
    return false; // Retorna false se houver uma exceção ou se nenhum registro for inserido
}
   
    
    public boolean salvarBackupLocal(List<ContaVeiculo> listaRegistros)throws Exception{
        //Cria um novo arquivo de backup da lista de registros de ContaEstacionamento       
        gravarBackup(caminhoPadrao + "backup"+ countBackup+".dat", listaRegistros);
        return false;
    }
    
    private void gravarBackup(String caminho, Object objeto) throws FileNotFoundException, IOException{        
        FileOutputStream outFile = new FileOutputStream(caminho);
        ObjectOutputStream s = new ObjectOutputStream(outFile);
        s.writeObject(objeto);
        s.close();
    }
    
    private Object lerBackup(String caminho) throws FileNotFoundException, IOException, ClassNotFoundException{        
        FileInputStream inFile = new FileInputStream(caminho);
        ObjectInputStream s = new ObjectInputStream(inFile);
        Object objeto = s.readObject();
        s.close();
        return objeto;
    }
}
